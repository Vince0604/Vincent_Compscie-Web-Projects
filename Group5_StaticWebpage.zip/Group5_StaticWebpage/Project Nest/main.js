// Initialize Typed.js for the text animation
var typed = new Typed(".text", {
    strings: ["Your Web Projects, Always Within Reach.", "Streamlining Access to Your Web Creations.", "Simplifying Project Storage for Developers."],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});


const navLinks = document.querySelectorAll(".navbar a");

// Add click event listener to each nav link
navLinks.forEach(link => {
    link.addEventListener("click", event => {
        event.preventDefault(); // Prevent default link behavior
        const targetId = link.getAttribute("href").substring(1);
        const targetSection = document.getElementById(targetId);

        // Add animation class to the target section
        targetSection.classList.add("animate-on-scroll");

        // Scroll to the section smoothly
        window.scrollTo({
            top: targetSection.offsetTop - 50, // Adjust for header
            behavior: "smooth"
        });

        // Remove animation class after the animation is complete
        setTimeout(() => {
            targetSection.classList.remove("animate-on-scroll");
        }, 1000); // Match the animation duration in CSS
    });
});



// Form submission handler
document.addEventListener("DOMContentLoaded", function () {
    const submitBtn = document.getElementById("submitBtn");
    submitBtn.addEventListener("click", function () {
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();
        const confirmationMessage = document.getElementById("confirmationMessage");

        if (name && email && message) {
            // Display confirmation message
            confirmationMessage.style.display = "block";

            // Clear the form fields
            document.getElementById("contactForm").reset();

            // Hide confirmation message after a delay
            setTimeout(() => {
                confirmationMessage.style.display = "none";
            }, 3000);
        } else {
            alert("Please fill out all fields.");
        }
    });
});


window.addEventListener("scroll", () => {
    const header = document.querySelector(".header");
    if (window.scrollY > 50) {
        header.style.background = "rgba(45, 45, 45, 1)"; // Solid background on scroll
    } else {
        header.style.background = "rgba(45, 45, 45, 0.9)"; // Semi-transparent background
    }
});

