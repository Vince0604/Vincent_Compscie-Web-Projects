<?php
$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $fullname = $_POST['fullname'];
    $address = $_POST['address'];
    $phone_number = $_POST['phone_number'];

    // Insert new customer into the database
    $sql_insert = "INSERT INTO customers (fullname, address, phonenumber) VALUES ('$fullname', '$address', '$phone_number')";
    if ($conn->query($sql_insert) === TRUE) {
        echo "<script>window.location.href = '{$_SERVER['HTTP_REFERER']}';</script>";
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}
?>
