<?php
$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Your SQL query
$sql = "SELECT customers.fullname, customers.address, schedules.dateofservice, equipments.equipmenttype, equipments.servicefeeperhour
        FROM schedules 
        INNER JOIN customers ON schedules.customersid = customers.customersid
        INNER JOIN equipments ON schedules.equipmentsid = equipments.equipmentsid";

// Execute the query
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        
        echo "Customer Name: " . $row["fullname"] . "<br>";
        echo "Customer Address: " . $row["address"] . "<br>";
        echo "Date of Service: " . $row["dateofservice"] . "<br>";
        echo "Equipment Type: " . $row["equipmenttype"] . "<br>";
        echo "Service Fee / Hour: " . $row["servicefeeperhour"] . "<br><br>";
    }
} else {
    echo "0 results";
}

// Close the connection
$conn->close();
?>

