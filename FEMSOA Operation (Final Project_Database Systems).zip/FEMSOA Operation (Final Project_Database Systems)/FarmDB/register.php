<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "<script>
    setTimeout(function() {
        alert('Registration Successful');
    }, 5000); // 5000 milliseconds = 5 seconds
    window.location.href = '{$_SERVER['HTTP_REFERER']}';
  </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
