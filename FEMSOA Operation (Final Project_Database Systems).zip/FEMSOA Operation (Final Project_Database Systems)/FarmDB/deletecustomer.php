<?php

include 'connect.php';

$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if delete request is received
if (isset($_GET['id'])) {
    $customer_id = $_GET['id'];

    // Delete customer from the database
    $sql_delete = "DELETE FROM customers WHERE customersid='$customer_id'";
    if ($conn->query($sql_delete) === TRUE) {
        header("Location: {$_SERVER['HTTP_REFERER']}");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}


exit();
?>
