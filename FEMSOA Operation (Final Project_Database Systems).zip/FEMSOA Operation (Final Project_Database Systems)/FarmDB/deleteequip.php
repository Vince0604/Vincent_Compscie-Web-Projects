<?php
// Include database connection
include 'connect.php';

// Check if table and id parameters are set
if (isset($_GET['table']) && isset($_GET['id'])) {
    $table = $_GET['table'];
    $id = $_GET['id'];

    // Formulate the delete query based on the table and primary key column
    $sql_delete = "DELETE FROM $table WHERE equipmentsid = '$id'"; // Assuming 'equipmentsid' is your primary key column

    // Execute the delete query
    if ($conn->query($sql_delete) === TRUE) {
        // Redirect back to the respective page after successful deletion
        switch ($table) {
            case 'equipments':
                header("Location: {$_SERVER['HTTP_REFERER']}");
                break;
            default:
                // Handle other cases or errors
                break;
        }
        exit; // Stop further execution
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
