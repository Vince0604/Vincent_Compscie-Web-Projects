<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
 header("Location: home.php"); // Redirect to homepage.php after successful login
    exit();
} 

else {
    echo "Invalid email or password";
}

$conn->close();
?>

