<?php
include 'connect.php';

$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $customer_id = $_POST['customer_id'];
    $equipment_id = $_POST['equipment_id'];
    $date_of_service = $_POST['date_of_service'];

    // Insert new schedule into the database
    $sql_insert = "INSERT INTO schedules (customersid, equipmentsid, dateofservice) VALUES ('$customer_id', '$equipment_id', '$date_of_service')";
    if ($conn->query($sql_insert) === TRUE) {
        echo "<script>window.location.href = '{$_SERVER['HTTP_REFERER']}';</script>";
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

exit();
?>
