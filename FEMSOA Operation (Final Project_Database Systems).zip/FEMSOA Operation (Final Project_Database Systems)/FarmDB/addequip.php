<?php
$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $equipment_id = $_POST['equipment_id'];
    $equipment_type = $_POST['equipment_type'];
    $service_fee_per_hour = $_POST['service_fee_per_hour'];

    // Insert new equipment into the database
    $sql_insert = "INSERT INTO equipments (equipmentsid, equipmenttype, servicefeeperhour) VALUES ('$equipment_id', '$equipment_type', '$service_fee_per_hour')";
    if ($conn->query($sql_insert) === TRUE) {
        // Redirect to the same page to display the updated list of equipment
        echo "<script>window.location.href = '{$_SERVER['HTTP_REFERER']}';</script>";
        exit;
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

$conn->close();
?>
