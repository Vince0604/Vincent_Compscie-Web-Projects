<?php
$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Your SQL queries for schedules.php, reports.php, and customers.php
$sql_schedules = "SELECT customers.fullname, customers.address, schedules.dateofservice, equipments.equipmenttype, equipments.servicefeeperhour
        FROM schedules 
        INNER JOIN customers ON schedules.customersid = customers.customersid
        INNER JOIN equipments ON schedules.equipmentsid = equipments.equipmentsid";

$sql_reports = "SELECT customers.fullname, customers.category, customers.address, schedules.dateofservice, records.actualdateofservice, equipments.equipmenttype, equipments.servicefeeperhour 
    FROM records 
    INNER JOIN customers ON records.customersid = customers.customersid 
    INNER JOIN equipments ON records.equipmentsid = equipments.equipmentsid 
    INNER JOIN schedules ON records.scheduleid = schedules.scheduleid";

$sql_customers = "SELECT * FROM farmdb.customers";

$sql_equipments = "SELECT * FROM farmdb.equipments";

// Execute the queries
$result_schedules = $conn->query($sql_schedules);
$result_customers = $conn->query($sql_customers);
$result_equipments = $conn->query($sql_equipments);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FEMSOA Operation</title>
    <!-- Linking Google font link for icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="content.css">
    <link rel="stylesheet" href="designercard.css">
 

</head>
<body>
<aside class="sidebar">
    <div class="logo">
        <img src="background.jpeg" alt="logo">
        <h2>FEMSOA Operation</h2>
    </div>
    <ul class="links">
        <h4>Main Menu</h4>
        <li>
            <span class="material-symbols-outlined">dashboard</span>
            <a href="#" onclick="showContent('dashboard')">Dashboard</a>
        </li>
        <li>
            <span class="material-symbols-outlined">group</span>
            <a href="#" onclick="showContent('customers')">Customers</a>
        </li>
        <li>
            <span class="material-symbols-outlined">ambient_screen</span>
            <a href="#" onclick="showContent('schedules')">Schedules</a>
        </li>
        <li>
            <span class="material-symbols-outlined"><img src="icons8-tractor-30.png" alt="icon"></i></span>
            <a href="#" onclick="showContent('equipments')">Equipments</a>
        </li>

        <hr>
        <h4>Credits</h4>
        <li>
    <span class="material-symbols-outlined">person</span>
    <a href="#" onclick="showDesignerContent()">Developers</a>
</li>
        <li class="logout-link">
            <span class="material-symbols-outlined">logout</span>
            <a id="logoutBtn" href="logout.php">Logout</a>
        </li>
    </ul>
</aside>

<div id="dashboardContent" style="display: none;">

    <!-- Content for Dashboard -->
    <div class="dashboard-info">
        <h3>Welcome to FEMSOA Operation</h3>
     
    </div>
    </div>

<div id="customersContent" style="display: none;">
<div id="addCustomerForm">
    <h4>Add Customer</h4>
    <form action="addcustomer.php" method="POST" id="customerForm">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="text" name="address" placeholder="Address" required>
        <input type="tel" name="phone_number" placeholder="Phone Number" required>
        <input type="submit" value="Add Customer" onclick="addCustomer()">
    </form>
</div>

    <!-- Content for Customers -->
    <?php
    // Output customers from customers.php
    if ($result_customers->num_rows > 0) {
      echo "<div class='content'>";
      echo "<h3>Customers</h3>";
      echo "<table>";
      echo "<tr><th>Customer ID</th><th>Fullname</th><th>Address</th><th>Phone Number</th><th>Options</th></tr>";
      // Output data of each row
      while ($row = $result_customers->fetch_assoc()) {
          echo "<tr>";
          echo "<td>" . $row["customersid"] . "</td>";
          echo "<td>" . $row["fullname"] . "</td>";
          echo "<td>" . $row["address"] . "</td>";
          echo "<td>" . $row["phonenumber"] . "</td>";
          echo "<td><a href='deletecustomer.php?id=" . $row["customersid"] . "' class='delete-link'>Delete</a></td>";


          echo "</tr>";
      }
      echo "</table>";
      echo "</div>";
  } else {
      echo "<p>No customers available.</p>";
  }
    ?>
</div>

<div id="schedulesContent" style="display: none;">
<div id="addScheduleForm">
    <h4>Add Schedule</h4>
    <form action="addschedule.php" method="POST" id="scheduleForm">
        <select name="customer_id" required>
            <option value="" disabled selected>Select Customer</option>
            <?php
            // Fetch customers from the database
            $sql_customers = "SELECT * FROM customers";
            $result_customers = $conn->query($sql_customers);
            if ($result_customers->num_rows > 0) {
                while ($row = $result_customers->fetch_assoc()) {
                    echo "<option value='" . $row["customersid"] . "'>" . $row["fullname"] . "</option>";
                }
            } else {
                echo "<option value='' disabled>No customers available</option>";
            }
            ?>
        </select>
        <select name="equipment_id" required>
            <option value="" disabled selected>Select Equipment</option>
            <?php
            // Fetch equipments from the database
            $sql_equipments = "SELECT * FROM equipments";
            $result_equipments = $conn->query($sql_equipments);
            if ($result_equipments->num_rows > 0) {
                while ($row = $result_equipments->fetch_assoc()) {
                    echo "<option value='" . $row["equipmentsid"] . "'>" . $row["equipmenttype"] . "</option>";
                }
            } else {
                echo "<option value='' disabled>No equipments available</option>";
            }
            ?>
        </select>
        <input type="date" name="date_of_service" required>
        <input type="submit" value="Add Schedule" onclick="addSchedule()">
    </form>
</div>

    <!-- Content for Schedules -->
    <div class="search-bar">
        <form method="GET">
            <input type="text" name="search" placeholder="Search">
            <input type="submit" value="Search">
        </form>
    </div>
    <?php
    // Check if search parameter is set
    if (isset($_GET['search'])) {
        $search = $_GET['search'];
        $sql_schedules = "SELECT customers.fullname, customers.address, schedules.dateofservice, equipments.equipmenttype, equipments.servicefeeperhour
        FROM schedules 
        INNER JOIN customers ON schedules.customersid = customers.customersid
        INNER JOIN equipments ON schedules.equipmentsid = equipments.equipmentsid
        WHERE customers.fullname LIKE '%$search%'
        OR customers.address LIKE '%$search%'
        OR schedules.dateofservice LIKE '%$search%'
        OR equipments.equipmenttype LIKE '%$search%'";
    } else {
        // Default query if search parameter is not set
        $sql_schedules = "SELECT customers.fullname, customers.address, schedules.dateofservice, equipments.equipmenttype, equipments.servicefeeperhour
        FROM schedules 
        INNER JOIN customers ON schedules.customersid = customers.customersid
        INNER JOIN equipments ON schedules.equipmentsid = equipments.equipmentsid";
    }

    // Execute the query
    $result_schedules = $conn->query($sql_schedules);

    // Display schedules based on search or all schedules
    if ($result_schedules->num_rows > 0) {
        echo "<div class='content'>";
        echo "<h3>Schedules</h3>";
        echo "<table>";
        echo "<tr><th>Customer Name</th><th>Customer Address</th><th>Date of Service</th><th>Equipment Type</th><th>Service Fee / Hour</th><th>Options</th></tr>";
        // Output data of each row
        while ($row = $result_schedules->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["fullname"] . "</td>";
            echo "<td>" . $row["address"] . "</td>";
            echo "<td>" . $row["dateofservice"] . "</td>";
            echo "<td>" . $row["equipmenttype"] . "</td>";
            echo "<td>" . $row["servicefeeperhour"] . "</td>";
            echo "<td><a href='deleteschedule.php?id=" . $row["fullname"] . "' class='delete-link'>Delete</a></td>"; // Adjust 'scheduleid' as per your column name
 

            echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "<p>No schedules available.</p>";
    }
    ?>

</div>
</div>


<div id="equipmentsContent" style="display: none;">
    <div class="add-equipment-form">
        <h4>Add Equipment</h4>
        <form action="addequip.php" method="POST" id="addEquipmentForm">
            <input type="text" name="equipment_id" placeholder="Equipment ID" required>
            <input type="text" name="equipment_type" placeholder="Equipment Type" required>
            <input type="number" step="0.01" name="service_fee_per_hour" placeholder="Service Fee / Hour" required>
            <input type="submit" value="Add Equipment" onclick="addEquipment()">
        </form>
    </div>

    <!-- PHP code to process form submission and display updated list -->
    <?php
    // Check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data
        $equipment_id = $_POST['equipment_id'];
        $equipment_type = $_POST['equipment_type'];
        $service_fee_per_hour = $_POST['service_fee_per_hour'];

        // Insert new equipment into the database
        $sql_insert = "INSERT INTO equipments (equipmentsid, equipmenttype, servicefeeperhour) VALUES ('$equipment_id', '$equipment_type', '$service_fee_per_hour')";
        if ($conn->query($sql_insert) === TRUE) {
            echo "<script>window.location.href = 'equipments.php';</script>";
        } else {
            echo "Error: " . $sql_insert . "<br>" . $conn->error;
        }
    }

    // Fetch and display updated list of equipments
    $sql_equipments = "SELECT * FROM equipments";
    $result_equipments = $conn->query($sql_equipments);
    if ($result_equipments->num_rows > 0) {
        echo "<div class='content'>";
        echo "<h3>Equipments</h3>";
        echo "<table>";
        echo "<tr><th>Equipment ID</th><th>Equipment Type</th><th>Service Fee / Hour</th><th>Options</th></tr>";
        while ($row = $result_equipments->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["equipmentsid"] . "</td>";
            echo "<td>" . $row["equipmenttype"] . "</td>";
            echo "<td>" . $row["servicefeeperhour"] . "</td>";
            echo "<td><a href='deleteequip.php?table=equipments&id=" . $row["equipmentsid"] . "' class='delete-link'>Delete</a></td>"; // Adjust 'equipmentsid' as per your column name
            echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    } else {
        echo "<p>No equipments available.</p>";
    }
    ?>
</div>


<div id="designerContent" style="display: none;">
    <h3>Developers</h3>
    <div class="designer-cards">
    <!-- Two cards above -->
    <div class="card">
        <img src="photo_6199696321984707004_y.jpg" alt="Designer 1">
        <div class="card-content">
            <h4>VINCENT L. BERNALES</h4>
            <p>Developer</p>
        </div>
    </div>
    <div class="card">
        <img src="photo_6199252424229764299_x.jpg" alt="Designer 2">
        <div class="card-content">
            <h4>CHARISSE LOIUSE S. TACLENDO</h4>
            <p>Assistant Developers</p>
        </div>
    </div>

    <div class="card">
        <img src="photo_6197163661374635221_y.jpg" alt="Designer 3">
        <div class="card-content">
            <h4>MA. JHIMEA P. MAGBANUA</h4>
            <p>Assistant Developers</p>
        </div>
    </div>
    <div class="card">
        <img src="photo_6199699349936651249_x.jpg" alt="Designer 4">
        <div class="card-content">
            <h4>JASON REY A. MORALDE</h4>
            <p>Assistant Developers</p>
        </div>
    </div>
    <div class="card">
        <img src="photo_6199350967959405125_y.jpg" alt="Designer 5">
        <div class="card-content">
            <h4>JADE P. TAGUPA</h4>
            <p>Assistant Developers</p>
        </div>
    </div>
</div>



<script>
    function showDesignerContent() {
        // Hide all other content
        var allContent = document.querySelectorAll('[id$=Content]');
        allContent.forEach(function (item) {
            item.style.display = 'none';
        });

        // Display designer content
        var designerContent = document.getElementById('designerContent');
        designerContent.style.display = 'block';
    }
</script>

<script>
    function addSchedule() {
        document.getElementById("scheduleForm").submit();
        // Reload the page to display updated list of schedules
        location.reload();
    }

    function addCustomer() {
        document.getElementById("customerForm").submit();
        // Reload the page to display updated list of customers
        location.reload();
    }
</script>

<script>
    function addEquipment() {
        document.getElementById("addEquipmentForm").submit();
        // Reload the page to display updated list of equipments
        location.reload();
    }
</script>


<script>
    function showContent(contentId) {
        var content = document.getElementById(contentId + 'Content');
        var allContent = document.querySelectorAll('[id$=Content]');
        allContent.forEach(function (item) {
            item.style.display = 'none';
        });
        content.style.display = 'block';
    }
</script>


</body>
</html>
