<?php
$hostname = "localhost"; // Change to your server IP or hostname
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database_name = "farmdb"; // Change to your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if schedule ID is provided via GET request
if (isset($_GET['id'])) {
    $schedule_id = $_GET['id'];

    // SQL to delete the schedule with the provided ID
    $sql_delete_schedule = "DELETE FROM schedules WHERE scheduleid = '$schedule_id'";

    // Execute the deletion query
    if ($conn->query($sql_delete_schedule) === TRUE) {
        header("Location: {$_SERVER['HTTP_REFERER']}");
    } else {
        echo "Error deleting schedule: " . $conn->error;
    }
} else {
    echo "Schedule ID not provided.";
}

// Close the connection
$conn->close();
?>
