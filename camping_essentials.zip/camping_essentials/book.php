<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = 1; // Example: Use session user ID in real implementation.
    $campsite_id = $_POST['campsite_id'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $price_per_night = $_POST['price_per_night'];
    $days = (strtotime($end_date) - strtotime($start_date)) / 86400;
    $total_price = $days * $price_per_night;

    $sql = "INSERT INTO bookings (user_id, campsite_id, start_date, end_date, total_price)
            VALUES ('$user_id', '$campsite_id', '$start_date', '$end_date', '$total_price')";

    if ($conn->query($sql) === TRUE) {
        echo "Booking successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $sql = "SELECT * FROM campsites WHERE id = $id";
    $result = $conn->query($sql);
    $campsite = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Campsite</title>
</head>
<body>
    <form method="post">
        <input type="hidden" name="campsite_id" value="<?php echo $campsite['id']; ?>">
        <input type="hidden" name="price_per_night" value="<?php echo $campsite['price_per_night']; ?>">
        <label>Start Date: <input type="date" name="start_date" required></label>
        <label>End Date: <input type="date" name="end_date" required></label>
        <button type="submit">Book</button>
    </form>
</body>
</html>
