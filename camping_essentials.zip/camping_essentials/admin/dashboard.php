<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Campsite Essentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
        }
        a {
            text-decoration: none;
            color: inherit;
        }

        /* Header Styling */
        .navbar {
            background-color: #1a1a1a;
            padding: 15px 0;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ff7f3f;
        }
        .nav-link {
            margin-right: 15px;
        }
        .form-control {
            background-color: #252525;
            color: #ffffff;
            border: none;
        }
        .form-control:focus {
            background-color: #252525;
            color: #ffffff;
            box-shadow: none;
        }
        .btn-search {
            background-color: #ff7f3f;
            color: #ffffff;
            border: none;
        }
        .btn-search:hover {
            background-color: #e56b2e;
            color: #ffffff;
        }

        /* Hero Section */
        .hero {
            padding: 100px 20px;
            text-align: center;
            background: #0d0d0d;
        }
        .hero h1 {
            font-size: 3rem;
            font-weight: bold;
        }
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }
        .btn-orange {
            background-color: #ff7f3f;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
        }
        .btn-orange:hover {
            background-color: #e56b2e;
        }

        /* Card Section */
        .card-container {
            padding: 50px 20px;
        }
        .custom-card {
            background-color: #252525;
            border: none;
            color: #ffffff;
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
            height: 100%;
        }
        .custom-card img {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
        .custom-card:hover {
            transform: scale(1.05);
            box-shadow: 0px 10px 15px rgba(0, 0, 0, 0.3);
        }

        /* Footer */
        footer {
            background-color: #0d0d0d;
            text-align: center;
            padding: 20px 0;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Camping Essentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">My Rentals</a>
                    </li>
                </ul>
                <!-- Right Nav Links -->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="javascript:void(0)" onclick="logout()">Logout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Guiding You to Our Campsite Adventures</h1>
            <p>Helping you find the information and equipment for your adventure.</p>
            <a href="location.php" class="btn btn-orange">Our Location</a>
            <a href="campsite_preview.php" class="btn btn-outline-light ms-3">Campsite Preview</a>
        </div>
    </section>

    <!-- Cards Section -->
    <section class="card-container">
        <div class="container">
            <div class="row">
                <!-- Card 1 -->
                <div class="col-md-4 mb-4">
                    <a href="fishing_tools_deals.php" class="text-decoration-none">
                        <div class="card custom-card text-center">
                            <img src="assets/fishing_tools_2.jpg" class="card-img-top" alt="Fishing Tools">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title">Fishing Tools</h5>
                                <p class="card-text flex-grow-1">Equip yourself with the best tools for a successful fishing trip.</p>
                                <span class="btn btn-dark mt-auto">View Deals</span>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- Card 2 -->
                <div class="col-md-4 mb-4">
                    <a href="tent_deals.php" class="text-decoration-none">
                        <div class="card custom-card text-center">
                            <img src="assets/tent_1.jpg" class="card-img-top" alt="Tent">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title">Campsite Tent</h5>
                                <p class="card-text flex-grow-1">Spacious, weather-proof tents for your camping needs.</p>
                                <span class="btn btn-dark mt-auto">View Deals</span>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- Card 3 -->
                <div class="col-md-4 mb-4">
                    <a href="bike_deals.php" class="text-decoration-none">
                        <div class="card custom-card text-center">
                            <img src="assets/bike_3.jpg" class="card-img-top" alt="Bikes">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title">Bikes</h5>
                                <p class="card-text flex-grow-1">Explore trails with our durable and comfortable bikes.</p>
                                <span class="btn btn-dark mt-auto">View Deals</span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>

    <!-- Bootstrap Script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        function logout() {
            // Clear the history and redirect to the login page
            window.location.href = "index.php"; // Replace with your actual login page URL
            window.location.replace("index.php"); // Ensures no history entry is retained
        }
    </script>
</body>
</html>
