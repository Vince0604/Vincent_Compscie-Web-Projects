<?php
// Database credentials
$host = 'localhost';
$dbname = 'camping_essentials'; // Replace with your database name
$username = 'root';      // Default XAMPP username
$password = '';          // Default XAMPP password (empty)

// Create database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$user = $_POST['username'];
$pass = $_POST['password'];

// Check if username and password are provided
if (empty($user) || empty($pass)) {
    echo "Both fields are required.";
    exit;
}

// Query the database
$sql = "SELECT * FROM users WHERE username = ? AND password = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $user, $pass);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Login successful
    session_start();
    $_SESSION['username'] = $user; // Store username in session
    header("Location: dashboard.php"); // Redirect to dashboard
    exit;
} else {
    // Invalid credentials
    echo "Invalid username or password.";
}

$stmt->close();
$conn->close();
?>
