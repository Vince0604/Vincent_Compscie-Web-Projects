<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Camping Essentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: url('assets/tent_3.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .login-container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.5);
            width: 400px;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #ff7f3f;
        }
        .form-label {
            color: #ffffff;
        }
        .form-control {
            border-radius: 20px;
            padding: 15px;
            background-color: #333;
            color: #ffffff;
            border: 1px solid #555;
        }
        .form-control:focus {
            border-color: #ff7f3f;
            box-shadow: 0 0 5px rgba(255, 127, 63, 0.7);
        }
        .btn-login {
            width: 100%;
            background-color: #ff7f3f;
            border: none;
            padding: 15px;
            border-radius: 20px;
            color: #fff;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .btn-login:hover {
            background-color: #ff5722;
        }
        .footer {
            text-align: center;
            position: fixed;
            bottom: 10px;
            width: 100%;
            color: #ffffff;
        }
        .error {
            color: #dc3545;
            font-size: 1rem;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    // Initialize an error message variable
    $error_message = '';

    // Process the form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        // Database connection details
        $host = 'localhost';
        $dbname = 'camping_essentials'; // Replace with your database name
        $db_user = 'root';       // Default XAMPP username
        $db_password = '';       // Default XAMPP password (empty)

        // Create database connection
        $conn = new mysqli($host, $db_user, $db_password, $dbname);

        // Check database connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query the database to validate user credentials
        $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Login successful - Redirect to dashboard
            header("Location: dashboard.php");
            exit;
        } else {
            // Invalid credentials
            $error_message = "Invalid Credentials";
        }

        $stmt->close();
        $conn->close();
    }
    ?>

    <div class="login-container">
        <h2>Login to Your Account</h2>
        <!-- Display error message if any -->
        <?php if (!empty($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form id="loginForm" action="" method="POST">
            <!-- Username -->
            <div class="mb-4">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <!-- Password -->
            <div class="mb-4">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <!-- Login Button -->
            <button type="submit" class="btn-login">Login</button>
        </form>
        <p class="text-center mt-3" style="color: #aaa;">Don't have an account? <a href="#" style="color: #ff7f3f;">Sign up</a></p>
    </div>

    <footer class="footer">
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>
</body>
</html>
