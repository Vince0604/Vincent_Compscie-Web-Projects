<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campsite Preview | Camping Essentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(45deg, #1a1a1a, #2a2a2a);
            color: #ffffff;
            margin: 0;
            padding: 0;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        /* Navbar Styling */
        nav.navbar {
            background-color: #222;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.4);
        }
        .navbar-brand {
            color: #ff7f3f !important;
            font-size: 1.8rem;
            font-weight: bold;
        }
        .navbar-nav .nav-link {
            color: #ffffff;
            font-size: 1.1rem;
            letter-spacing: 1px;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover {
            color: #ff7f3f !important;
            text-decoration: underline;
        }

        /* Campsite Preview Section */
        .campsite-container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 60px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.6);
            width: 85%;
            margin: 50px auto;
            animation: fadeIn 1s ease-in-out;
        }
        .campsite-container h2 {
            text-align: center;
            color: #ff7f3f;
            margin-bottom: 40px;
            font-size: 3rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.7);
        }

        /* Image Grid */
        .image-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            transition: all 0.3s ease;
        }
        .image-card {
            position: relative;
            overflow: hidden;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            cursor: pointer;
            transition: transform 0.4s ease-in-out, box-shadow 0.3s ease;
        }
        .image-card:hover {
            transform: scale(1.1);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.5);
        }
        .image-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: opacity 0.4s ease-in-out;
        }
        .image-card:hover img {
            opacity: 0.75;
        }
        .image-card .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .image-card:hover .overlay {
            opacity: 1;
        }
        .overlay p {
            color: #ffffff;
            font-size: 18px;
            font-style: italic;
            text-align: center;
            letter-spacing: 1px;
            text-shadow: 3px 3px 5px rgba(0, 0, 0, 0.7);
            padding: 10px;
            max-width: 80%;
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }

        /* Footer Styling */
        .footer {
            text-align: center;
            color: #ffffff;
            background-color: #222;
            padding: 20px;
            margin-top: 40px;
            box-shadow: 0px -4px 6px rgba(0, 0, 0, 0.4);
        }

        /* Animation for the page content */
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Camping Essentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">My Rentals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Profile</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Campsite Preview Section -->
    <div class="campsite-container">
        <h2>Explore Our Campsites</h2>
        
        <!-- Image Grid -->
        <div class="image-grid">
            <!-- Image 1 -->
            <div class="image-card">
                <img src="assets/camp6.jpg" alt="Campsite 1">
                <div class="overlay">
                    <p>"A place where the stars meet the earth."</p>
                </div>
            </div>
            <!-- Image 2 -->
            <div class="image-card">
                <img src="assets/camp3.jpg" alt="Campsite 2">
                <div class="overlay">
                    <p>"Experience nature in its purest form."</p>
                </div>
            </div>
            <!-- Image 3 -->
            <div class="image-card">
                <img src="assets/camp2.jpg" alt="Campsite 3">
                <div class="overlay">
                    <p>"Find your peace under the trees."</p>
                </div>
            </div>
            <!-- Image 4 -->
            <div class="image-card">
                <img src="assets/camp1.jpg" alt="Campsite 4">
                <div class="overlay">
                    <p>"A perfect getaway for the soul."</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
