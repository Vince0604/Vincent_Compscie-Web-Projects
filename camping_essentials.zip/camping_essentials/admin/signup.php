<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | Camping Essentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: url('assets/tent_3.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .signup-container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.5);
            width: 400px;
        }
        .signup-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #ff7f3f;
        }
        .form-label {
            color: #ffffff;
        }
        .form-control {
            border-radius: 20px;
            padding: 15px;
            background-color: #333;
            color: #ffffff;
            border: 1px solid #555;
        }
        .form-control:focus {
            border-color: #ff7f3f;
            box-shadow: 0 0 5px rgba(255, 127, 63, 0.7);
        }
        .btn-signup {
            width: 100%;
            background-color: #ff7f3f;
            border: none;
            padding: 15px;
            border-radius: 20px;
            color: #fff;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .btn-signup:hover {
            background-color: #ff5722;
        }
        .footer {
            text-align: center;
            position: fixed;
            bottom: 10px;
            width: 100%;
            color: #ffffff;
        }
        .error {
            color: #dc3545;
            font-size: 1rem;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    // Initialize an error message variable
    $error_message = '';

    // Process the form submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        // Database connection details
        $host = 'localhost';
        $dbname = 'camping_essentials'; // Replace with your database name
        $db_user = 'root';       // Default XAMPP username
        $db_password = '';       // Default XAMPP password (empty)

        // Create database connection
        $conn = new mysqli($host, $db_user, $db_password, $dbname);

        // Check database connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if username or email already exists
        $sql_check = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("ss", $username, $email);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // Username or email already exists
            $error_message = "Username or Email already exists!";
        } else {
            // Insert new user into the database
            $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $username, $email, $password);
            $stmt->execute();

            // Successful signup, redirect to login page
            header("Location: login.php");
            exit;
        }

        $stmt_check->close();
        $stmt->close();
        $conn->close();
    }
    ?>

    <div class="signup-container">
        <h2>Create Your Account</h2>
        <!-- Display error message if any -->
        <?php if (!empty($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form id="signupForm" action="" method="POST">
            <!-- Username -->
            <div class="mb-4">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
            </div>
            <!-- Email -->
            <div class="mb-4">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
            </div>
            <!-- Password -->
            <div class="mb-4">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <!-- Signup Button -->
            <button type="submit" class="btn-signup">Sign Up</button>
        </form>
        <p class="text-center mt-3" style="color: #aaa;">Already have an account? <a href="login.php" style="color: #ff7f3f;">Log in</a></p>
    </div>

    <footer class="footer">
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>
</body>
</html>
