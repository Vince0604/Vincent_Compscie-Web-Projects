<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>The Campsite Essentials</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.1.0/fonts/remixicon.css" rel="stylesheet" />
    <style>
        /* General Styling */
        body {
            background-color: #0d0d0d;
            color: #ffffff;
            font-family: 'Poppins', sans-serif;
        }
        a {
            text-decoration: none;
            color: inherit;
            transition: color 0.3s;
        }
        a:hover {
            color: #ff7f3f;
        }

        /* Navbar */
        .navbar {
            background-color: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5);
        }
        .navbar-brand {
            font-weight: bold;
            color: #ff7f3f !important;
            letter-spacing: 2px;
            font-size: 1.8rem;
        }
        .nav-link {
            font-size: 1.1rem;
            margin-right: 15px;
        }
        .nav-link:hover {
            color: #ff7f3f !important;
        }

        /* Hero Section */
        .hero {
            position: relative;
            height: 100vh;
            background: url('assets/tent_1.jpg') no-repeat center center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }
        .hero::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }
        .hero-content {
            position: relative;
            z-index: 2;
        }
        .hero h1 {
            font-size: 4rem;
            font-weight: bold;
            color: #ff7f3f;
            margin-bottom: 20px;
            animation: fadeInDown 1s ease-in-out;
        }
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            color: #f8f9fa;
            animation: fadeInUp 1.5s ease-in-out;
        }
        .btn-orange {
            background-color: #ff7f3f;
            color: #ffffff;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            font-weight: bold;
            transition: transform 0.3s ease, background 0.3s ease;
        }
        .btn-orange:hover {
            background-color: #e56b2e;
            transform: scale(1.1);
        }

        /* Social Media */
        .socials {
            text-align: center;
            margin-top: 30px;
        }
        .socials a {
            font-size: 2rem;
            margin: 0 10px;
            transition: transform 0.3s ease;
            color: #ff7f3f;
        }
        .socials a:hover {
            transform: translateY(-5px);
        }

        /* Footer */
        footer {
            background-color: #1a1a1a;
            padding: 15px 0;
            text-align: center;
            color: #aaaaaa;
        }

        /* Animations */
        @keyframes fadeInDown {
            0% {
                opacity: 0;
                transform: translateY(-50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
            <a class="navbar-brand" href="#">Camping Essentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="signup.php">Signup</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
    <div class="hero-content">
        <h1>Explore Nature’s Beauty</h1>
        <p>Your adventure starts here. Let’s make your camping dreams come true.</p>
        <a href="login.php" class="btn btn-orange">LOGIN</a>
    </div>
</section>


    <!-- Social Media -->
    <div class="socials">
        <a href="#"><i class="ri-facebook-circle-fill"></i></a>
        <a href="#"><i class="ri-instagram-line"></i></a>
        <a href="#"><i class="ri-twitter-fill"></i></a>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>

    <!-- Bootstrap Script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
