<?php
// Include the database connection
include('db.php');

// Handle the search query if it's submitted (via AJAX or the search bar)
$search_term = isset($_GET['search']) ? $_GET['search'] : '';
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'price'; // Default sort by price
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'ASC'; // Default sort ascending

// Sanitize the input to prevent SQL injection
$search_term = $conn->real_escape_string($search_term);
$sort_by = $conn->real_escape_string($sort_by);
$sort_order = $conn->real_escape_string($sort_order);

// Query to fetch bike deals from the database
if ($search_term == '') {
    $sql = "SELECT bike_deals, availability, price, bike_description, bike_tagline, image_url FROM bikes ORDER BY $sort_by $sort_order";
} else {
    $sql = "SELECT bike_deals, availability, price, bike_description, bike_tagline, image_url 
            FROM bikes 
            WHERE bike_deals LIKE '%$search_term%' 
            OR bike_description LIKE '%$search_term%' 
            OR bike_tagline LIKE '%$search_term%' 
            ORDER BY $sort_by $sort_order";
}

// Execute the query
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bike Deals</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
        }
        a {
            text-decoration: none;
            color: #ffffff;
        }

        /* Navbar */
        .navbar {
            background-color: #1a1a1a;
            padding: 15px 0;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: #ff7f3f;
        }
        .nav-link {
            margin-right: 15px;
        }

        /* Product Card Section */
        .deals-container {
            padding: 50px 20px;
        }
        .product-card {
            background-color: #252525;
            border: 1px solid #333;
            border-radius: 10px;
            color: #ffffff;
            transition: transform 0.2s, box-shadow 0.3s;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .product-card img {
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            object-fit: cover;
            width: 100%;
            height: 200px; /* Set a fixed height */
        }
        .product-card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.5);
        }
        .product-card .btn {
            background-color: #ff7f3f;
            border: none;
            color: white;
            margin-top: auto; /* Push the button to the bottom */
        }
        .product-card .btn:hover {
            background-color: #e56b2e;
        }

        /* Availability Styling */
        .availability {
            font-weight: bold;
            margin-top: 10px;
        }
        .in-stock {
            color: #28a745; /* Green */
        }
        .out-of-stock {
            color: #dc3545; /* Red */
        }

        /* Sorting UI */
        .sort-container {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px; /* Add spacing to move it above the cards */
        }
        .sort-label {
            font-size: 1rem;
            color: #ff7f3f;
            font-weight: bold;
        }
        .sort-dropdown {
            background-color: #333;
            border: 1px solid #555;
            color: white;
            border-radius: 5px;
            padding: 5px 15px;
            font-size: 1rem;
            cursor: pointer;
        }
        .sort-dropdown:hover {
            background-color: #ff7f3f;
            border-color: #ff7f3f;
        }

        /* Footer */
        footer {
            background-color: #0d0d0d;
            text-align: center;
            padding: 20px 0;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Camping Essentials</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">My Rentals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Profile</a>
                    </li>
                </ul>
                <!-- Search Form -->
                <form class="d-flex ms-3" id="search-form" method="get">
                    <input class="form-control me-2" type="search" id="search" name="search" placeholder="Search Bikes" value="<?php echo htmlspecialchars($search_term); ?>" aria-label="Search">
                    <button class="btn btn-outline-warning" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <!-- Deals Section -->
    <section class="deals-container">
        <div class="container">
            <h2 class="text-center mb-5">Explore Our Bike Deals</h2>
            
            <!-- Sorting UI (now placed above the cards) -->
            <div class="sort-container">
                <span class="sort-label">Sort By:</span>
                <form class="d-flex gap-3">
                    <select class="sort-dropdown" name="sort_by" id="sort_by">
                        <option value="price" <?php if ($sort_by == 'price') echo 'selected'; ?>>Price</option>
                        <option value="bike_deals" <?php if ($sort_by == 'bike_deals') echo 'selected'; ?>>Deal Name</option>
                    </select>
                    <select class="sort-dropdown" name="sort_order" id="sort_order">
                        <option value="ASC" <?php if ($sort_order == 'ASC') echo 'selected'; ?>>Ascending</option>
                        <option value="DESC" <?php if ($sort_order == 'DESC') echo 'selected'; ?>>Descending</option>
                    </select>
                </form>
            </div>

            <div class="row" id="product-container">
                <?php
                // Check if there are any results
                if ($result->num_rows > 0) {
                    // Loop through the results and display each product
                    while ($row = $result->fetch_assoc()) {
                        $bike_deals = $row['bike_deals'];
                        $availability = $row['availability'];
                        $price = $row['price'];
                        $bike_description = $row['bike_description'];
                        $bike_tagline = $row['bike_tagline'];
                        $image_url = $row['image_url'];
                        $stock_class = $availability > 0 ? 'in-stock' : 'out-of-stock';
                        $button_disabled = $availability > 0 ? '' : 'disabled';
                        $button_text = $availability > 0 ? 'Add to Cart' : 'Out of Stock';
                        echo "
                        <div class='col-md-4 mb-4'>
                            <div class='product-card text-center p-3'>
                                <img src='assets/$image_url' alt='$bike_deals'>
                                <h5 class='mt-3'>$bike_deals</h5>
                                <p>$bike_description</p>
                                <p>$bike_tagline</p>
                                <h6 class='text-success'>$$price</h6>
                                <p class='availability $stock_class'>" . ($availability > 0 ? 'In Stock' : 'Out of Stock') . "</p>
                                <button class='btn w-100 mt-2' $button_disabled>$button_text</button>
                            </div>
                        </div>
                        ";
                    }
                } else {
                    echo "<p class='text-center text-white'>No bike deals available at the moment.</p>";
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 TheCampsite. All rights reserved.</p>
    </footer>

    <!-- Bootstrap Script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function(){
            function loadBikes(search_term = '', sort_by = '', sort_order = '') {
                $.get(window.location.href, { search: search_term, sort_by: sort_by, sort_order: sort_order }, function(data) {
                    // Extract and replace the product list in the container
                    var productHtml = $(data).find('#product-container').html();
                    $('#product-container').html(productHtml);
                });
            }

            // Detect when the search input changes
            $('#search').on('input', function() {
                var search_term = $(this).val();
                loadBikes(search_term, $('#sort_by').val(), $('#sort_order').val());
            });

            // Detect when the sorting options change
            $('#sort_by, #sort_order').on('change', function() {
                var sort_by = $('#sort_by').val();
                var sort_order = $('#sort_order').val();
                loadBikes($('#search').val(), sort_by, sort_order);
            });
        });
    </script>
</body>
</html>

<?php
// Close the connection
$conn->close();
?>
